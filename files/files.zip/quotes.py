"""
Question1
Write Python Program to Count the Occurrences of Each Word
and Also Count the Number of Words in a "quotes.txt" File. Sample
Content of "quotes.txt" File is Given Below.

(Happiness is the longing for repetition.
Artificial intelligence is no match for natural stupidty.)

Question 2
Write Python Program to Find the Longest Word in a File. Get the File
Name from User. (Assume User Enters the File Name as "animals.txt" and its
Sample Contents are as Below)

(Rhinocerose Porcupine  Squirrel Flamingo Pangolin Woodpecker 
Salmander  Antelope  Kangaroo)

Question 3
Write Python Program to Reverse Each Word in "secret_societies.txt" file.
Sample Content of "secret_societies.txt" is Given Below

(Scret)



"""