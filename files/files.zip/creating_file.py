with open("filename.txt", "r") as file_handler:
    print(file_handler.readlines())


my = open("filename.txt", "r")
my.readlines()


