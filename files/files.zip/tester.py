text = "Hello world"

result = text.split()

print(result)